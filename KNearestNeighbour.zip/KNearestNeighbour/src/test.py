'''
Created on 26.02.2016

@author: Masus04
'''
import math

print(range(10)[:0])